var convert = require('./convert'),
    func = convert('isUndefined', require('../isUndefined'), require('./_falseOptions'));

func.placeholder = require('./placeholder');
module.exports = func;
