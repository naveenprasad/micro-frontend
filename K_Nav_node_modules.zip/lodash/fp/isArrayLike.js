var convert = require('./convert'),
    func = convert('isArrayLike', require('../isArrayLike'), require('./_falseOptions'));

func.placeholder = require('./placeholder');
module.exports = func;
