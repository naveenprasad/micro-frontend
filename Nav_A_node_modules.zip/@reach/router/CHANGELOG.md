## v1.2.0

- a7a1c84 fixed focus being stolen from [autofocus] elements
- 8a56262 Added `hash` and `search` to server location
- 1c13f8a Added history "PUSH" and "POP" actions to listener callback
- 534f67c Added globalHistory to index exports
- 8cb6e83 allow falsey children in Router

## v1.1.1

- e0338b5c Removed vestigial dependencies from package.json
- fix/automated linting

## v1.1.0

- 53f06958 Added ref forwarding and `innerRef` fallback

## v1.0.0

- Added literally everything.
